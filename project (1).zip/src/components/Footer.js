import React from 'react';
import { FaFacebook, FaTwitter, FaLinkedin } from 'react-icons/fa';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="bg-gray-800 text-white py-10 mt-20">
      <div className="container mx-auto px-6 grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="flex flex-col items-center md:items-start">
          <Link to="/" className="flex items-center space-x-2 mb-4">
            <img src="https://www.svgrepo.com/show/13500/avocado.svg" alt="Aguacate Express Logo" className="h-10 w-10" />
            <span className="text-3xl font-extrabold text-green-400 tracking-tight">Aguacate <span className="text-green-200">Express</span></span>
          </Link>
          <p className="text-gray-400 text-center md:text-left">
            Tu socio logístico de confianza para el transporte de aguacates frescos.
          </p>
        </div>

        <div className="text-center md:text-left">
          <h3 className="text-xl font-semibold mb-4 text-green-300">Navegación</h3>
          <ul className="space-y-2">
            <li><Link to="/" className="text-gray-400 hover:text-green-200 transition-colors duration-300">Inicio</Link></li>
            <li><Link to="/servicios" className="text-gray-400 hover:text-green-200 transition-colors duration-300">Servicios</Link></li>
            <li><Link to="/cotizacion" className="text-gray-400 hover:text-green-200 transition-colors duration-300">Cotización</Link></li>
            <li><Link to="/kpis" className="text-gray-400 hover:text-green-200 transition-colors duration-300">KPIs</Link></li>
            <li><Link to="/contacto" className="text-gray-400 hover:text-green-200 transition-colors duration-300">Contacto</Link></li>
          </ul>
        </div>

        <div className="text-center md:text-left">
          <h3 className="text-xl font-semibold mb-4 text-green-300">Síguenos</h3>
          <div className="flex justify-center md:justify-start space-x-4">
            <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-blue-500 transition-colors duration-300">
              <FaFacebook className="w-7 h-7" />
            </a>
            <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-blue-400 transition-colors duration-300">
              <FaTwitter className="w-7 h-7" />
            </a>
            <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-blue-700 transition-colors duration-300">
              <FaLinkedin className="w-7 h-7" />
            </a>
          </div>
          <p className="text-gray-400 mt-6">
            © {new Date().getFullYear()} Aguacate Express. Todos los derechos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;