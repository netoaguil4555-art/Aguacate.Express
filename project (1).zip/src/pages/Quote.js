import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { MapPin, DollarSign, Truck, Fuel, User, ArrowLeftRight } from 'lucide-react';

const destinations = [
  { name: 'Ciudad de México', distance: 500 },
  { name: 'Guadalajara', distance: 300 },
  { name: 'Monterrey', distance: 900 },
  { name: 'Tijuana', distance: 2500 },
  { name: 'Cancún', distance: 2000 },
  { name: 'Puebla', distance: 600 },
  { name: 'Querétaro', distance: 400 },
  { name: 'Veracruz', distance: 700 },
  { name: 'Mérida', distance: 1800 },
  { name: 'Chihuahua', distance: 1500 },
];

const Quote = () => {
  const [selectedDestination, setSelectedDestination] = useState('');
  const [cost, setCost] = useState(null);
  const [loading, setLoading] = useState(false);

  const calculateCost = () => {
    if (!selectedDestination) {
      setCost(null);
      return;
    }

    setLoading(true);
    setCost(null); // Clear previous cost

    setTimeout(() => {
      const destination = destinations.find(d => d.name === selectedDestination);
      if (destination) {
        const distance = destination.distance; // km from Michoacán (approx)

        // Costos aproximados (estos son solo ejemplos, ajusta según tus costos reales)
        const fuelCostPerKm = 15; // MXN por km (ida y vuelta)
        const operatorSalaryPerDay = 1500; // MXN por día
        const truckReturnCostPerKm = 5; // MXN por km (costo adicional por el regreso del camión vacío)
        const baseCost = 5000; // Costo base por servicio

        const totalFuelCost = distance * fuelCostPerKm;
        const estimatedDays = Math.ceil((distance * 2) / 800); // Asumiendo 800km/día de ida y vuelta
        const totalOperatorSalary = operatorSalaryPerDay * estimatedDays;
        const totalTruckReturnCost = distance * truckReturnCostPerKm;

        const totalCost = baseCost + totalFuelCost + totalOperatorSalary + totalTruckReturnCost;
        setCost({
          total: totalCost,
          details: {
            fuel: totalFuelCost,
            operator: totalOperatorSalary,
            return: totalTruckReturnCost,
            base: baseCost,
            distance: distance,
            days: estimatedDays
          }
        });
      } else {
        setCost(null);
      }
      setLoading(false);
    }, 1500); // Simulate network delay
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-lime-100 pt-24 pb-16">
      <div className="container mx-auto px-6 max-w-3xl">
        <motion.h1
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-5xl font-extrabold text-center text-green-800 mb-12"
        >
          Calcula tu <span className="text-green-600">Cotización</span>
        </motion.h1>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="bg-white rounded-xl p-8 shadow-lg border border-green-200"
        >
          <div className="mb-6">
            <label htmlFor="destination" className="block text-gray-700 text-lg font-semibold mb-3 flex items-center">
              <MapPin className="w-6 h-6 mr-2 text-green-600" />
              Destino del Viaje (desde Michoacán):
            </label>
            <select
              id="destination"
              value={selectedDestination}
              onChange={(e) => setSelectedDestination(e.target.value)}
              className="w-full px-5 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 text-gray-800 text-lg appearance-none bg-white pr-10"
            >
              <option value="">Selecciona un destino</option>
              {destinations.map((dest) => (
                <option key={dest.name} value={dest.name}>
                  {dest.name}
                </option>
              ))}
            </select>
          </div>

          <motion.button
            onClick={calculateCost}
            disabled={!selectedDestination || loading}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className={`w-full py-4 rounded-lg text-xl font-bold transition-all duration-300 flex items-center justify-center ${
              selectedDestination && !loading
                ? 'bg-green-600 text-white hover:bg-green-700 shadow-md'
                : 'bg-gray-300 text-gray-600 cursor-not-allowed'
            }`}
          >
            {loading ? (
              <svg className="animate-spin h-7 w-7 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
            ) : (
              <>
                <DollarSign className="w-7 h-7 mr-3" />
                Calcular Costo
              </>
            )}
          </motion.button>

          {cost && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="mt-8 p-6 bg-green-50 rounded-lg border border-green-200 shadow-inner"
            >
              <h2 className="text-3xl font-bold text-green-700 mb-4 text-center">
                Costo Estimado: <span className="text-green-900">${cost.total.toLocaleString('es-MX')} MXN</span>
              </h2>
              <p className="text-gray-700 text-center mb-6">
                Para el transporte de aguacates a <span className="font-semibold">{selectedDestination}</span> ({cost.details.distance} km).
              </p>

              <div className="space-y-3 text-gray-700">
                <div className="flex items-center justify-between">
                  <span className="flex items-center text-lg"><Fuel className="w-5 h-5 mr-2 text-green-600" /> Costo de Combustible:</span>
                  <span className="font-semibold text-lg">${cost.details.fuel.toLocaleString('es-MX')} MXN</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="flex items-center text-lg"><User className="w-5 h-5 mr-2 text-green-600" /> Sueldo del Operador ({cost.details.days} días):</span>
                  <span className="font-semibold text-lg">${cost.details.operator.toLocaleString('es-MX')} MXN</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="flex items-center text-lg"><ArrowLeftRight className="w-5 h-5 mr-2 text-green-600" /> Regreso del Camión:</span>
                  <span className="font-semibold text-lg">${cost.details.return.toLocaleString('es-MX')} MXN</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="flex items-center text-lg"><Truck className="w-5 h-5 mr-2 text-green-600" /> Costo Base del Servicio:</span>
                  <span className="font-semibold text-lg">${cost.details.base.toLocaleString('es-MX')} MXN</span>
                </div>
              </div>
              <p className="text-sm text-gray-500 mt-6 text-center">
                *Este es un costo estimado y puede variar. Para una cotización exacta, por favor contáctanos.
              </p>
            </motion.div>
          )}
        </motion.div>
      </div>
    </div>
  );
};

export default Quote;