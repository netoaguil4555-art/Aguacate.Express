import React from 'react';
import { motion } from 'framer-motion';
import { Truck, Clock, ShieldCheck } from 'lucide-react';
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-lime-100 pt-24">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-green-600 to-lime-700 text-white py-20 md:py-32 overflow-hidden">
        <div className="absolute inset-0 opacity-30"> {/* Aumentado la opacidad para que se vea más */}
          <img src="https://images.unsplash.com/photo-1587334274328-6414f99d747c?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="Aguacates" className="w-full h-full object-cover" />
        </div>
        <div className="container mx-auto px-6 relative z-10 text-center">
          <motion.h1
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-5xl md:text-7xl font-extrabold mb-6 leading-tight drop-shadow-lg"
          >
            Aguacate <span className="text-green-300">Express</span>
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="text-xl md:text-2xl mb-10 max-w-3xl mx-auto font-light"
          >
            Tu socio logístico 3PL para el transporte expedito de aguacates de Michoacán a toda la República Mexicana.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.6 }}
          >
            <Link
              to="/cotizacion"
              className="inline-block bg-white text-green-700 hover:bg-green-100 px-10 py-4 rounded-full text-xl font-bold shadow-lg transform hover:scale-105 transition-all duration-300"
            >
              ¡Cotiza tu envío ahora!
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Services Overview */}
      <section className="py-16 md:py-24 bg-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 z-0">
          <img src="https://images.unsplash.com/photo-1587334274328-6414f99d747c?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="Aguacates de fondo" className="w-full h-full object-cover" />
        </div>
        <div className="container mx-auto px-6 relative z-10">
          <h2 className="text-4xl font-bold text-center text-gray-800 mb-12">
            Nuestros <span className="text-green-600">Servicios</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="bg-green-50/90 rounded-xl p-8 shadow-lg text-center border border-green-200 backdrop-blur-sm"
            >
              <Truck className="w-16 h-16 text-green-600 mx-auto mb-6" />
              <h3 className="text-2xl font-semibold text-gray-800 mb-4">Transporte Expedito</h3>
              <p className="text-gray-600">
                Entregas de aguacates frescos en 24 a 48 horas a cualquier parte de México desde Michoacán.
              </p>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="bg-green-50/90 rounded-xl p-8 shadow-lg text-center border border-green-200 backdrop-blur-sm"
            >
              <Clock className="w-16 h-16 text-green-600 mx-auto mb-6" />
              <h3 className="text-2xl font-semibold text-gray-800 mb-4">Logística 3PL Integral</h3>
              <p className="text-gray-600">
                Gestión completa de tu cadena de suministro, desde la recolección hasta la entrega final.
              </p>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
              className="bg-green-50/90 rounded-xl p-8 shadow-lg text-center border border-green-200 backdrop-blur-sm"
            >
              <ShieldCheck className="w-16 h-16 text-green-600 mx-auto mb-6" />
              <h3 className="text-2xl font-semibold text-gray-800 mb-4">Calidad y Seguridad</h3>
              <p className="text-gray-600">
                Garantizamos la frescura y seguridad de tus productos con los más altos estándares.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 md:py-24 bg-gradient-to-br from-green-700 to-lime-800 text-white text-center relative overflow-hidden">
        <div className="absolute inset-0 opacity-20 z-0">
          <img src="https://images.unsplash.com/photo-1587334274328-6414f99d747c?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="Aguacates de fondo" className="w-full h-full object-cover" />
        </div>
        <div className="container mx-auto px-6 relative z-10">
          <motion.h2
            initial={{ opacity: 0, y: -30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="text-4xl font-bold mb-6"
          >
            ¿Listo para optimizar tu logística?
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="text-xl mb-10 max-w-2xl mx-auto"
          >
            Confía en Aguacate Express para un servicio rápido, seguro y eficiente.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.6 }}
          >
            <Link
              to="/contacto"
              className="inline-block bg-white text-green-700 hover:bg-green-100 px-10 py-4 rounded-full text-xl font-bold shadow-lg transform hover:scale-105 transition-all duration-300"
            >
              Contáctanos
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Home;