import React from 'react';
import { motion } from 'framer-motion';
import { Truck, Package, Warehouse, MapPin, Clock, ShieldCheck } from 'lucide-react';
import { Link } from 'react-router-dom';

const services = [
  {
    icon: Truck,
    title: 'Transporte Expedito Nacional',
    description: 'Movilizamos tus aguacates desde Michoacán a cualquier destino en México en tiempo récord (24-48 horas), garantizando la frescura y calidad.'
  },
  {
    icon: Package,
    title: 'Gestión de Carga y Descarga',
    description: 'Manejo profesional de tus productos, asegurando que la carga y descarga se realicen de manera eficiente y sin daños.'
  },
  {
    icon: Warehouse,
    title: 'Almacenamiento Estratégico',
    description: 'Ofrecemos soluciones de almacenamiento temporal en puntos clave para optimizar tus rutas y tiempos de entrega.'
  },
  {
    icon: MapPin,
    title: 'Rastreo en Tiempo Real',
    description: 'Monitorea el estado y la ubicación de tu envío en todo momento, brindándote total transparencia y tranquilidad.'
  },
  {
    icon: Clock,
    title: 'Optimización de Rutas',
    description: 'Utilizamos tecnología avanzada para diseñar las rutas más eficientes, reduciendo costos y tiempos de tránsito.'
  },
  {
    icon: ShieldCheck,
    title: 'Seguro de Mercancía',
    description: 'Protegemos tu inversión con pólizas de seguro que cubren cualquier eventualidad durante el transporte.'
  }
];

const Services = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-lime-100 pt-24 pb-16 relative overflow-hidden">
      <div className="absolute inset-0 opacity-10 z-0">
        <img src="https://images.unsplash.com/photo-1587334274328-6414f99d747c?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="Aguacates de fondo" className="w-full h-full object-cover" />
      </div>
      <div className="container mx-auto px-6 relative z-10">
        <motion.h1
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-5xl font-extrabold text-center text-green-800 mb-12"
        >
          Nuestros <span className="text-green-600">Servicios</span>
        </motion.h1>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ scale: 1.03, boxShadow: '0 10px 20px rgba(0,0,0,0.1)' }}
              className="bg-white/90 rounded-xl p-8 shadow-lg border border-green-200 flex flex-col items-center text-center backdrop-blur-sm"
            >
              <service.icon className="w-16 h-16 text-green-600 mb-6" />
              <h2 className="text-2xl font-bold text-gray-800 mb-4">{service.title}</h2>
              <p className="text-gray-600 leading-relaxed">{service.description}</p>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: services.length * 0.1 }}
          className="mt-16 text-center"
        >
          <p className="text-xl text-gray-700 mb-6">
            En Aguacate Express, nos comprometemos a ofrecerte soluciones logísticas que superen tus expectativas.
          </p>
          <Link
            to="/cotizacion"
            className="inline-block bg-green-600 text-white hover:bg-green-700 px-8 py-4 rounded-full text-lg font-bold shadow-lg transform hover:scale-105 transition-all duration-300"
          >
            ¡Cotiza tu envío y experimenta la diferencia!
          </Link>
        </motion.div>
      </div>
    </div>
  );
};

export default Services;