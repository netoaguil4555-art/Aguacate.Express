import React from 'react';
import { motion } from 'framer-motion';
import { Wrench, Smile, CheckCircle, Clock, Zap } from 'lucide-react';

const kpis = [
  {
    icon: Wrench,
    title: 'Mantenimiento de Flota',
    value: '98%',
    description: 'Porcentaje de disponibilidad de la flota. ¡Nuestros camiones casi nunca se detienen!',
    color: 'text-blue-600',
    bg: 'bg-blue-50'
  },
  {
    icon: Smile,
    title: 'Satisfacción del Cliente',
    value: '95%',
    description: 'Índice de satisfacción de nuestros clientes. ¡Nos aman tanto como a los aguacates!',
    color: 'text-yellow-600',
    bg: 'bg-yellow-50'
  },
  {
    icon: CheckCircle,
    title: 'Pedidos Concluidos',
    value: '99.7%',
    description: 'Porcentaje de pedidos entregados exitosamente. ¡Casi perfecto, como un aguacate maduro!',
    color: 'text-green-600',
    bg: 'bg-green-50'
  },
  {
    icon: Clock,
    title: 'Optimización de Tiempo de Pedido',
    value: '26 hrs',
    description: 'Tiempo promedio desde la solicitud hasta la entrega. ¡Más rápido que un rayo, pero con aguacates!',
    color: 'text-purple-600',
    bg: 'bg-purple-50'
  },
  {
    icon: Zap,
    title: 'Tiempo de Respuesta',
    value: '15 min',
    description: 'Tiempo promedio de respuesta a consultas. ¡No te dejamos esperando, a menos que sea por un aguacate!',
    color: 'text-red-600',
    bg: 'bg-red-50'
  }
];

const KPIs = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-lime-100 pt-24 pb-16">
      <div className="container mx-auto px-6">
        <motion.h1
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-5xl font-extrabold text-center text-green-800 mb-12"
        >
          Nuestros <span className="text-green-600">Indicadores Clave (KPIs)</span>
        </motion.h1>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {kpis.map((kpi, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ scale: 1.03, boxShadow: '0 10px 20px rgba(0,0,0,0.1)' }}
              className={`rounded-xl p-8 shadow-lg border ${kpi.bg} border-gray-200 flex flex-col items-center text-center`}
            >
              <kpi.icon className={`w-16 h-16 ${kpi.color} mb-6`} />
              <h2 className="text-2xl font-bold text-gray-800 mb-3">{kpi.title}</h2>
              <p className={`text-5xl font-extrabold ${kpi.color} mb-4`}>{kpi.value}</p>
              <p className="text-gray-600 leading-relaxed">{kpi.description}</p>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: kpis.length * 0.1 }}
          className="mt-16 text-center"
        >
          <p className="text-xl text-gray-700 mb-6">
            En Aguacate Express, la transparencia y la eficiencia son nuestro pan de cada día (o nuestro aguacate de cada día).
          </p>
          <Link
            to="/contacto"
            className="inline-block bg-green-600 text-white hover:bg-green-700 px-8 py-4 rounded-full text-lg font-bold shadow-lg transform hover:scale-105 transition-all duration-300"
          >
            ¡Hablemos de tus necesidades logísticas!
          </Link>
        </motion.div>
      </div>
    </div>
  );
};

export default KPIs;