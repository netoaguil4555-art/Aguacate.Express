import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin } from 'lucide-react';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });
  const [status, setStatus] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setStatus('sending');
    // Simulate API call
    setTimeout(() => {
      console.log('Form Data:', formData);
      setStatus('success');
      setFormData({ name: '', email: '', message: '' });
      setTimeout(() => setStatus(''), 3000); // Clear status after 3 seconds
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-lime-100 pt-24 pb-16">
      <div className="container mx-auto px-6 max-w-4xl">
        <motion.h1
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-5xl font-extrabold text-center text-green-800 mb-12"
        >
          Contáctanos <span className="text-green-600">Hoy</span>
        </motion.h1>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="bg-white rounded-xl p-8 shadow-lg border border-green-200"
          >
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Información de Contacto</h2>
            <div className="space-y-6">
              <div className="flex items-center">
                <Mail className="w-7 h-7 text-green-600 mr-4" />
                <div>
                  <h3 className="text-xl font-semibold text-gray-700">Email</h3>
                  <p className="text-gray-600">2024397006@uteq.edu.mx</p>
                </div>
              </div>
              <div className="flex items-center">
                <Phone className="w-7 h-7 text-green-600 mr-4" />
                <div>
                  <h3 className="text-xl font-semibold text-gray-700">Teléfono</h3>
                  <p className="text-gray-600">+52 442 873 6533</p>
                </div>
              </div>
              <div className="flex items-start">
                <MapPin className="w-7 h-7 text-green-600 mr-4 mt-1" />
                <div>
                  <h3 className="text-xl font-semibold text-gray-700">Oficinas Centrales</h3>
                  <p className="text-gray-600">
                    Av. Aguacate #123, Col. La Huerta, <br />
                    Uruapan, Michoacán, México
                  </p>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="bg-white rounded-xl p-8 shadow-lg border border-green-200"
          >
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Envíanos un Mensaje</h2>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-gray-700 text-lg font-semibold mb-2">Nombre</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 text-gray-800"
                  required
                />
              </div>
              <div>
                <label htmlFor="email" className="block text-gray-700 text-lg font-semibold mb-2">Email</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 text-gray-800"
                  required
                />
              </div>
              <div>
                <label htmlFor="message" className="block text-gray-700 text-lg font-semibold mb-2">Mensaje</label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  rows="5"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 text-gray-800"
                  required
                ></textarea>
              </div>
              <motion.button
                type="submit"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                disabled={status === 'sending'}
                className={`w-full py-4 rounded-lg text-xl font-bold transition-all duration-300 ${
                  status === 'sending'
                    ? 'bg-gray-400 text-gray-700 cursor-not-allowed'
                    : 'bg-green-600 text-white hover:bg-green-700 shadow-md'
                }`}
              >
                {status === 'sending' ? 'Enviando...' : 'Enviar Mensaje'}
              </motion.button>
              {status === 'success' && (
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-center text-green-600 font-semibold mt-4"
                >
                  ¡Mensaje enviado con éxito! Te responderemos pronto.
                </motion.p>
              )}
            </form>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Contact;